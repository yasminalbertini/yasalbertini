let ball;
let leftPaddle;
let rightPaddle;
let leftScore = 0;
let rightScore = 0;

function setup() {
  createCanvas(800, 400);

  ball = new Ball();
  leftPaddle = new Paddle(true);
  rightPaddle = new Paddle(false);
}

function draw() {
  background(0);
  
  ball.update();
  ball.show();
  ball.checkPaddle(leftPaddle);
  ball.checkPaddle(rightPaddle);
  
  leftPaddle.update();
  rightPaddle.update();
  
  leftPaddle.show();
  rightPaddle.show();
  
  displayScores();
}

function keyPressed() {
  if (key === 'W') {
    leftPaddle.move(-1);
  } else if (key === 'S') {
    leftPaddle.move(1);
  }
  
  if (keyCode === UP_ARROW) {
    rightPaddle.move(-1);
  } else if (keyCode === DOWN_ARROW) {
    rightPaddle.move(1);
  }
}

function keyReleased() {
  if (key === 'W' || key === 'S') {
    leftPaddle.move(0);
  }
  
  if (keyCode === UP_ARROW || keyCode === DOWN_ARROW) {
    rightPaddle.move(0);
  }
}

class Ball {
  constructor() {
    this.radius = 10;
    this.reset();
  }

  update() {
    this.x += this.xSpeed;
    this.y += this.ySpeed;

    if (this.y <= 0 || this.y >= height) {
      this.ySpeed *= -1;
    }

    if (this.x <= 0) {
      rightScore++;
      this.reset();
    } else if (this.x >= width) {
      leftScore++;
      this.reset();
    }
  }

  reset() {
    this.x = width / 2;
    this.y = height / 2;
    this.xSpeed = random([-5, 5]);
    this.ySpeed = random([-3, 3]);
  }

  show() {
    fill(255);
    noStroke();
    ellipse(this.x, this.y, this.radius * 2);
  }

  checkPaddle(paddle) {
    if (this.x - this.radius < paddle.x + paddle.width &&
        this.x + this.radius > paddle.x &&
        this.y - this.radius < paddle.y + paddle.height &&
        this.y + this.radius > paddle.y) {
      this.xSpeed *= -1;
      // Add a bit of randomness to the angle to make it less predictable
      this.ySpeed += random(-1, 1);
      this.ySpeed = constrain(this.ySpeed, -5, 5);
    }
  }
}

class Paddle {
  constructor(isLeft) {
    this.width = 10;
    this.height = 100;
    this.y = height / 2 - this.height / 2;
    this.x = isLeft ? 20 : width - 20 - this.width;
    this.ySpeed = 0;
  }

  update() {
    this.y += this.ySpeed;
    this.y = constrain(this.y, 0, height - this.height);
  }

  move(direction) {
    this.ySpeed = direction * 5;
  }

  show() {
    fill(255);
    noStroke();
    rect(this.x, this.y, this.width, this.height);
  }
}

function displayScores() {
  textSize(32);
  fill(255);
  textAlign(CENTER, CENTER);
  text(leftScore, width / 4, 50);
  text(rightScore, 3 * width / 4, 50);
}




 



